<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="css/stil.css">
<script src="https://kit.fontawesome.com/996064a3d3.js" crossorigin="anonymous"></script>    
</head>
<body>
    <div class="wrapper-row1">
    
        <div id="topbar" class="clear-topbar">
            
        <nav>
            <ul class="ul-topbar">
                <li class="li-topbar"><a href="index.php"><i class="fa-solid fa-house ikon"></i>
                Home</a></li>
                <li class="li-topbar"><a href=""> <i class="fa-solid fa-arrow-right-to-bracket ikon"></i>Giriş</a></li>
                <li class="li-topbar"><a href=""><i class="fa-solid fa-basket-shopping ikon"></i>Sepet</a></li>
            </ul>
        </nav>
        </div>
    </div>
    <div class="wrapper-row2">
        <div class="container">
            <div class="row">
        <header id="header">
            <div id="hgroup">
                <h1 class="logo">
                    <a href="">Saplament</a>
                </h1>
                <small>Protein, Yardımcılar, Vitaminler</small>
            </div>
            <div class="navbar col-sm-12">
        <ul class="ul-nav">
        <?php $category = mysqli_query($baglanti," SELECT * FROM category");?>
<?php while($satir= mysqli_fetch_array($category)) : ?>
    <li class='li-nav'><a href='category.php?category=<?=$satir['id']?>'><?=$satir['category_name']?></a></li>
<?php endwhile;?>

        </ul>
    </header>
            </div>
            </div>
            </div>
    </div>
    <div class="wrapper-row3">
        <div class="container">
            <div class="content">
                <div id="showcase">
                <ul class="clear">
               
                    </ul>
                
                </div>
            </div>
        </div>
    </div>

    <footer>
        <div class="footer">
            <div class="footer-container">
                <div class="footer-row">
                    <div class="footer-row1">
                      <h1 class="footer-h1">İletişim</h1>
                    <ul class="footer-ul">
                            <li><i class="fa-solid fa-location-pin ikon-footer"></i>
                        İzmir/Torbalı Cumhuriyet mah.no19</li>
                            <hr>
                            <li><i class="fa-solid fa-envelope ikon-footer"></i>
                            mehmett_234@outlook.com</li>
                            <hr>
                            <li> <i class="fa-solid fa-phone ikon-footer "></i>
                        0532 123 45 67</li>
                            <hr>
                            <li class="footer-aboutUs"><i class="fa-solid fa-envelope ikon-footer"></i>
                            <a href="" > Bize Ulaşın</a></li>
                            <hr>
                        </ul>
                    </div>
                    <div class="footer-row2">
                        <h1 class="footer-h1">
                            Bizi Takip Et
                        </h1>
                    <ul class="footer-ul-follow">
                            <li><a href=""><i class="fa-brands fa-instagram footer-ikon"></i></a></li>
                            <li><a href=""><i class="fa-brands fa-facebook footer-ikon"></i></a></li>
                            <li><a href=""><i class="fa-brands fa-twitter footer-ikon"></i></a></li>
                            <li><a href=""><i class="fa-brands fa-youtube footer-ikon"></i></a></li>
                        </ul>
                    </div>
                    <div class="footer-row3">
                        <h1 class="footer-h1">Hakkımızda</h1>
                    <ul class="footer-ul footer-aboutUs">
                            <li><a href=""> Hakkımızda</a></li>
                            <li><a href=""> Gizlilik Politikası</a></li>
                            <li><a href="">Şartlar ve koşullar</a> </li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </footer>
</body>
</html>atistirmalik/bellanut-fistikEzmesi.jpeg