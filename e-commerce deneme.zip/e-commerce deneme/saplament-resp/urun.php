<?php 
include("baglan.php");

$urun_id = $_GET['id'];

$sql=mysqli_query($baglanti,"SELECT * FROM product WHERE id=".$urun_id);
 $cek=mysqli_fetch_array($sql);
 $urun_foto=$cek['urun_foto'];
 $urun_adi=$cek['urun_adi'];
 $urun_fiyat=$cek['urun_fiyat'];
$urun_desc=$cek['urun_desc'];

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Saplament | Anasayfa</title>
    <link rel="stylesheet" href="css/stil.css">
    <!-- CSS only -->
    <script src="https://cdn.jsdelivr.net/npm/jquery@3.6.0/dist/jquery.slim.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/js/bootstrap.bundle.min.js"></script>
<script src="https://kit.fontawesome.com/996064a3d3.js" crossorigin="anonymous"></script>    
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0-beta1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-0evHe/X+R7YkIZDRvuzKMRqM+OrBnVFBL6DOitfPri4tjfHxaWutUpFmBp4vmVor" crossorigin="anonymous">

</head>
<body>
    <div class="banner"></div>
    <div class="wrapper-row1">
    <div class="container">
    
        <div id="topbar" class="clear-topbar">
            
        
        <?php include("includes/navbar.php");?>
        </div>
    </div>
    </div>
   
    <div class="wrapper-row2">
    <div class="container cont-row-2 " >
    <div id="hgroup order-1" >
                <h1 class="logo">
                    <a href="#">Saplament</a>
                </h1>
                <small>Protein, Yardımcılar, Vitaminler</small>
            </div>

            <div class="row">     
                    <header id="header">
            
            <div class="navbar order-2">
        <ul class="ul-nav col-sm-12 ">
        <?php $category = mysqli_query($baglanti," SELECT * FROM category");?>
<?php while($satir= mysqli_fetch_array($category)) : ?>
   <li class='li-nav'><a href='category.php?category=<?=$satir['id']?>'><?=$satir['category_name']?></a></li>
<?php endwhile;?>

        </ul>
            </div>
        </header>
        </div>
        </div>
        </div>
        <div class="wrapper-row3">
        <div class="urun-body">
            <div class="container" style="padding-left: 0px;padding-right: 0px;">
        <div class="urun-detay" style="width:100%">
        <div class="cont-r">

        
            <div class="urun-baslik"><b><?=$urun_adi?></b></div>
            <div class="cont-urun">
            <div class="urun-resim"> 
                   <img src="<?= $urun_foto?>" class="figure-size" style="width:250px;height:250px"> 
                </div>
                <div class="combo">
                <form action="cart-vt.php" method="get" class="form">
                    <select name="urun_adet"  class="combo-box">
                        <option value="1">1</option>
                        <option value="2">2</option>
                        <option value="3">3</option>
                        <option value="4">4</option>
                        <option value="5">5</option>
                        <option value="6">6</option>
                        <option value="7">7</option>
                        <option value="8">8</option>
                        <option value="9">9</option>
                        <option value="10">10</option>&
                    </select> 
                    
                    <div class="sepet-btn" style="flex-wrap:wrap">
                        <input type="hidden" name="id" value="<?=$cek['id'];?>">
                        <button type="submit" class="sepet">Satın Al</a>
                    </div>
                    
                
            </form>
        </div>
    </div>
        </div>
            <div class="cont">
                
            
            
            <div class="urun-desc"><?=$urun_desc?>  </div>
           
        </div>


            </div>

        </div>
        </div>
        </div>
        </div>
    <footer>
        <div class="footer">
            <div class="footer-container">
                <div class="footer-row">
                    <div class="footer-row1">
                      <h1 class="footer-h1">İletişim</h1>
                    <ul class="footer-ul">
                            <li><i class="fa-solid fa-location-pin ikon-footer"></i>
                        İzmir/Torbalı Cumhuriyet mah.no19</li>
                            <hr style="margin-bottom: 0px;margin-top: 0px;">
                            <li><i class="fa-solid fa-envelope ikon-footer"></i>
                            mehmett_234@outlook.com</li>
                            <hr style="margin-bottom: 0px;margin-top: 0px;">
                            <li> <i class="fa-solid fa-phone ikon-footer "></i>
                        0532 123 45 67</li>
                            <hr style="margin-bottom: 0px;margin-top: 0px;">
                            <li class="footer-aboutUs"><i class="fa-solid fa-envelope ikon-footer"></i>
                            <a href="iletisim.php" > Bize Ulaşın</a></li>
                            <hr style="margin-bottom: 0px;margin-top: 0px;">
                        </ul>
                    </div>
                    <div class="footer-row2">
                        <h1 class="footer-h1">
                            Bizi Takip Et
                        </h1>
                    <ul class="footer-ul-follow">
                            <li><a href=""><i class="fa-brands fa-instagram footer-ikon"></i></a></li>
                            <li><a href=""><i class="fa-brands fa-facebook footer-ikon"></i></a></li>
                            <li><a href=""><i class="fa-brands fa-twitter footer-ikon"></i></a></li>
                            <li><a href="https://www.youtube.com/watch?v=FJRMldSmy-M"><i class="fa-brands fa-youtube footer-ikon"></i></a></li>
                        </ul>
                    </div>
                    <div class="footer-row3">
                        <h1 class="footer-h1">Hakkımızda</h1>
                    <ul class="footer-ul footer-aboutUs">
                            <li><a href=""> Hakkımızda</a></li>
                            <hr style="margin-bottom: 0px;margin-top: 0px;">
                            <li><a href=""> Gizlilik Politikası</a></li>
                            <hr style="margin-bottom: 0px;margin-top: 0px;">
                            <li><a href="">Şartlar ve koşullar</a> </li>
                            <hr style="margin-bottom: 0px;margin-top: 0px;">
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </footer>
    
</body>
</html>