<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    
  
</head>
<body>
    <?php
include("baglan.php");

if($_POST)
{
	
mysqli_set_charset($baglanti,"utf8");
$UrunAdi = $_POST["UrunAdi"];
$UrunFiyat = $_POST["UrunFiyat"];
$UrunType=$_POST["UrunType"];
$UrunDesc = $_POST["UrunDesc"];
$dizin='resim/';
$yuklenecekDosya=$dizin.basename($_FILES['foto']['name']);
move_uploaded_file($_FILES['foto']['tmp_name'],$yuklenecekDosya);
if($ekle = mysqli_query($baglanti,"INSERT INTO product(urun_adi,urun_fiyat,urun_type
,urun_desc,urun_foto)
 VALUES('$UrunAdi','$UrunFiyat','$UrunType','$UrunDesc','$yuklenecekDosya')"));
 {
   echo "Veri başarılı bir şekilde ekrana yazıldı";
 }
}
?>
    <div class="container">
    <form action="productdeneme.php" method="post" enctype="multipart/form-data">
        <p >
            Ürün Adı=
            <input type="text" name="UrunAdi" id="UrunAdi"  class="ad">
        </p>
        <p>
            Ürün Fiyatı=
            <input type="text" name="UrunFiyat" id="UrunFiyat"  class="soyad">
        </p>
        <p>
            Ürün Tipi=
            <input type="text" name="UrunType" id="UrunType"  >
        </p>
        <p>
            Ürün Açıklaması=
            <input type="text" name="UrunDesc" id="UrunDesc"  class="bolum">
        </p>
        
        <input type="file" name="foto"/>
        <p class="submit">
            <input type="submit" name="kaydet" id="kaydet" value="Submit" />
        </p>
    </div>
    </form>
    
</div>
<div class="table">  
<table border="1" >
<th> ID </th>
<th> AD </th>
<th> SOYAD </th>
<th> TC </th>
<th> BÖLÜM </th>
<th> Fotoğraf </th>
<?php
 $baglanti= mysqli_connect('localhost','admin','123456','saplament');

/* if(!$baglanti){
	
echo "Bağlantı Hatası!".mysqli_connect_error();
}
else{
	
echo "Veritabanına Başarıyla Bağlandı";
} */ 

$sonuc = mysqli_query($baglanti," SELECT * FROM product");

while($satir= mysqli_fetch_array($sonuc)){
	
echo '<tr>';	
echo '<td>'.$satir['id'].'</td>'; 

echo '<td>'.$satir['urun_adi'].'</td>'; 	
echo '<td>'.$satir['urun_fiyat'].'</td>'; 
echo '<td>'.$satir['urun_type'].'</td>'; 
echo '<td>'.$satir['urun_desc'].'</td>'; 
echo '<td> <img src="'.$satir['urun_foto'].'" alt="foto" width="100px"
 height="100px"></a></td>';
echo '</tr>';

}




?>
</table>
</div>
</body>
</html>