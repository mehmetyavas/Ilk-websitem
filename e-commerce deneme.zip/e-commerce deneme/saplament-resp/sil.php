<?php

include("../../baglan.php");
if ($_GET) {
    $baglanti=mysqli_connect('localhost','admin',
    '123456','saplament');
    mysqli_set_charset($baglanti,"UTF8");
    if ($sil=mysqli_query($baglanti,"DELETE FROM cart WHERE id=".(int)$_GET['id'])) {

        
        header("location:cart.php");
    }
    else {
        echo"işlem cart curt";
    }
}

?>