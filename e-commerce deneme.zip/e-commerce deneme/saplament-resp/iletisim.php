<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title> Saplament | İletişim  </title>
    <link rel="stylesheet" href="css/iletisim.css">
    
    <script src="https://kit.fontawesome.com/f768aec904.js" crossorigin="anonymous"></script>

    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Roboto+Mono:wght@300&display=swap" rel="stylesheet">
    
    <link rel="stylesheet" href="owl/owl.carousel.min.css">
    <link rel="stylesheet" href="owl/owl.theme.default.min.css">


</head>
<body>
    
     <section id="iletisim">
         <div class="container">
             <h3 id="iletisimh3">İletişim</h3>
             
             <form action="iletisim.php" method="post" autocomplete="off">
                         <input type="text" name="isim" placeholder="Ad Soyad" required class="form-control">
                         <input type="text" name="tel" placeholder="Telefon Numarası" required class="form-control">
                    
                     
                        <input type="email" name="mail" placeholder="Email Adresiniz" required class="form-control">
                        <input type="text" name="konu" placeholder="Konu" required class="form-control">
                     
                     
                     <textarea name="mesaj" id="" cols="30" placeholder="Mesaj Giriniz..." rows="10" required class="form-control"> </textarea>

                     <input type="submit" value="Gönder" >
                
                    </div>
              
            
             </form> 

             <footer>
                 <div id="copyright">2022 Tüm Hakları Saklıdır</div>
                 <div id="social-footer">
                    <a href="#"><i class="fa-brands fa-facebook-square social"></i></a>
                    <a href="#"><i class="fa-brands fa-twitter-square social"></i></a>
                    <a href="#"><i class="fa-brands fa-instagram-square social"></i></a>
                 </div>

                 <a href="#menu"><i class="fa-solid fa-angle-up" id="yukari"></i></a>
             </footer>
         </div>
     </section>


<script src="https://code.jquery.com/jquery-3.6.0.slim.min.js" integrity="sha256-u7e5khyithlIdTpu22PHhENmPcRdFiHRjhAuHcs05RI=" crossorigin="anonymous"></script>
<script src="owl/owl.carousel.min.js"></script>
<script src="owl/script.js"></script>


</body>
</html>


<?php
   include("baglan.php");

   if(isset($_POST["isim"], $_POST["tel"], $_POST["mail"], $_POST["konu"], $_POST["mesaj"]))
   {
       $adsoyad=$_POST["isim"];
       $telefon=$_POST["tel"];
       $email=$_POST["mail"];
       $konu=$_POST["konu"];
       $mesaj=$_POST["mesaj"];


    
       if($ekle=mysqli_query($baglanti,"INSERT INTO iletisim (adsoyad, telefon, email, konu, mesaj) VALUES ('".$adsoyad."', '".$telefon."', '".$email."', '".$konu."', '".$mesaj."')"))
       {
           echo "<script> alert('Mesajınız Başarılı Bir Şekilde İletilmiştir.') </script>" ;
       }

       else{
        echo "<script> alert('Mesajınız Gönderilirken Bir Hata Oluştu.') </script>" ;
       }
   }
?>