<?php
session_start();
ob_start();
session_destroy();
unset($_SESSION['kulanici']);
echo"<center> Çıkış yaptınız. </center>";

header("refresh:2; url=login.php");

ob_end_flush();

?>