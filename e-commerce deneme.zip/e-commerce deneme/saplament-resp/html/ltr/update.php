<?php
ob_start();
session_start();
require '../../admin/db_conn.php';
if($_SESSION["K_Adi"]=='admin'){


?>
<?php
 include("../../baglan.php");

$duzenle=mysqli_query($baglanti,"SELECT * FROM product WHERE id=".$_GET['id']);

if ($satir=mysqli_fetch_array($duzenle))
?>



<!DOCTYPE html>
<html dir="ltr" lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <!-- Tell the browser to be responsive to screen width -->
    <meta name="viewport" content="width=device-width, initial-scale=1">
    
    <title>Panel | saplament.site</title>
    <link rel="canonical" href="https://www.wrappixel.com/templates/xtreme-admin-lite/" />
    <!-- Favicon icon -->
    <link rel="icon" type="image/png" sizes="16x16" href="../../assets/images/favicon.png">
    <!-- Custom CSS -->
    <link href="../../dist/css/style.min.css" rel="stylesheet">
    <link href="../../dist/css/style.css" rel="stylesheet">
    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
    <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
    <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
<![endif]-->
</head>

<body>
    <!-- ============================================================== -->
    <!-- Preloader - style you can find in spinners.css -->
    <!-- ============================================================== -->
    <div class="preloader">
        <div class="lds-ripple">
            <div class="lds-pos"></div>
            <div class="lds-pos"></div>
        </div>
    </div>
    <!-- ============================================================== -->
    <!-- Main wrapper - style you can find in pages.scss -->
    <!-- ============================================================== -->
    <div id="main-wrapper" data-layout="vertical" data-navbarbg="skin5" data-sidebartype="full"
        data-sidebar-position="absolute" data-header-position="absolute" data-boxed-layout="full">
        <!-- ============================================================== -->
        <!-- Topbar header - style you can find in pages.scss -->
        <!-- ============================================================== -->
        <header class="topbar" data-navbarbg="skin5">
            <nav class="navbar top-navbar navbar-expand-md navbar-dark">
                <div class="navbar-header" data-logobg="skin5" style="height:64px">
                    <!-- ============================================================== -->
                    <!-- Logo -->
                    <!-- ============================================================== -->
                    
                    
                    <a class="saplament" href="../../index.php">Saplament</a>






                    
                    <!-- ============================================================== -->
                    <!-- End Logo -->
                    <!-- ============================================================== -->
                    <!-- This is for the sidebar toggle which is visible on mobile only -->
                    <a class="nav-toggler waves-effect waves-light d-block d-md-none" href="javascript:void(0)"><i
                            class="ti-menu ti-close"></i></a>
                </div>
                <!-- ============================================================== -->
                <!-- End Logo -->
                <!-- ============================================================== -->
                <div class="navbar-collapse collapse" id="navbarSupportedContent" data-navbarbg="skin5">
                    <!-- ============================================================== -->
                    <!-- toggle and nav items -->
                    <!-- ============================================================== -->
                    
                    <!-- ============================================================== -->
                    <!-- Right side toggle and nav items -->
                    <!-- ============================================================== -->
                    <ul class="navbar-nav float-end">
                        <!-- ============================================================== -->
                        <!-- User profile and search -->
                        <!-- ============================================================== -->
                        
                        <!-- ============================================================== -->
                        <!-- User profile and search -->
                        <!-- ============================================================== -->
                    </ul>
                </div>
            </nav>
        </header>
        <!-- ============================================================== -->
        <!-- End Topbar header -->
        <!-- ============================================================== -->
        <!-- ============================================================== -->
        <!-- Left Sidebar - style you can find in sidebar.scss  -->
        <!-- ============================================================== -->
        <aside class="left-sidebar" data-sidebarbg="skin6">
            <!-- Sidebar scroll-->
            <div class="scroll-sidebar">
                <!-- Sidebar navigation-->
                <nav class="sidebar-nav">
                    <ul id="sidebarnav">
                        <!-- User Profile-->
                        <li>
                            <!-- User Profile-->
                            <div class="user-profile d-flex no-block dropdown m-t-20">
                                <div class="user-pic"><img src="../../assets/images/users/1.jpg" alt="users"
                                        class="rounded-circle" width="40" /></div>
                                <div class="user-content hide-menu m-l-10">
                                    <a href="#" class="" id="Userdd" role="button"
                                        data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                        <h5 class="m-b-0 user-name font-medium">admin <i
                                                class="fa fa-angle-down"></i></h5>
                                    </a>
                                    <div class="dropdown-menu dropdown-menu-end" aria-labelledby="Userdd">
                                        
                                        <div class="dropdown-divider"></div>
                                        <a class="dropdown-item" href="../../admin/logout.php"><i
                                                class="fa fa-power-off m-r-5 m-l-5"></i> Logout</a>
                                    </div>
                                </div>
                            </div>
                            <!-- End User Profile-->
                        </li>
                        
                        <!-- User Profile-->
                        <li class="sidebar-item"> <a class="sidebar-link waves-effect waves-dark sidebar-link"
                                href="dashboard.php" aria-expanded="false"><i class="mdi mdi-view-dashboard"></i><span
                                    class="hide-menu">Dashboard</span></a></li>
                                    <li class="sidebar-item"> <a class="sidebar-link waves-effect waves-dark sidebar-link"
                                href="product-add.php" aria-expanded="false"><i
                                    class="mdi mdi-cart-outline"></i><span class="hide-menu">Product</span></a></li>
                                    <li class="sidebar-item"> <a class="sidebar-link waves-effect waves-dark sidebar-link"
                                href="product-update.php" aria-expanded="false"><i
                                    class="mdi mdi-cart-outline"></i><span class="hide-menu">Product Update</span></a></li>
                        <li class="sidebar-item"> <a class="sidebar-link waves-effect waves-dark sidebar-link"
                                href="table.php" aria-expanded="false"><i class="mdi mdi-border-all"></i><span
                                    class="hide-menu">Table</span></a></li>
                        
                    </ul>

                </nav>
                <!-- End Sidebar navigation -->
            </div>
            <!-- End Sidebar scroll-->
        </aside>
        <!-- ============================================================== -->
        <!-- End Left Sidebar - style you can find in sidebar.scss  -->
        <!-- ============================================================== -->
        <!-- ============================================================== -->
        <!-- Page wrapper  -->
        <!-- ============================================================== -->
        <div class="page-wrapper">
            <!-- ============================================================== -->
            <!-- Bread crumb and right sidebar toggle -->
            <!-- ============================================================== -->
            <div class="page-breadcrumb">
                <div class="row align-items-center">
                    <div class="col-5">
                        <h4 class="page-title">Update</h4>
                        <div class="d-flex align-items-center">
                            <nav aria-label="breadcrumb">
                                <ol class="breadcrumb">
                                    <li class="breadcrumb-item"><a href="#">Home</a></li>
                                    <li class="breadcrumb-item active" aria-current="page">Library</li>
                                </ol>
                            </nav>
                        </div>
                    </div>
                </div>
            </div>
            <!-- ============================================================== -->
            <!-- End Bread crumb and right sidebar toggle -->
            <!-- ============================================================== -->
            <!-- ============================================================== -->
            <!-- Container fluid  -->
            <!-- ============================================================== -->
            <div class="container-fluid">
                <!-- ============================================================== -->
                <!-- Start Page Content -->
                <!-- ============================================================== -->
                <!-- Row -->
                <div class="row">
                    <!-- Column -->
                    <div class="col-lg-4 col-xlg-3 col-md-5">
                        <div class="card">
                            <div class="card-body">
                                
                           

        <!--FOTo**************************************************************************************-->
        <figure style="margin-bottom: 0px;width: 220px;">
                    <img src="<?php echo '../../'.$satir['urun_foto']; ?>" class="figure-size" style="height:240px;width:240px"  >
                    
       
                   




                            </div>
                           
                            
                        </div>
                    </div>
                    <!-- Column -->
                    <!-- Column -->
                    <div class="col-lg-8 col-xlg-9 col-md-7">
                        <div class="card">
                            <div class="card-body">
                                <form action="" method="post" class="form-horizontal form-material mx-2">
                                <?php// echo htmlspecialchars($_SERVER["PHP_SELF"]."?id={$_GET['id']}");?>
                                  
                                <div class="form-group">
                                        <label class="col-md-12">Ürün Adı</label>
                                        <div class="col-md-12">
                                            <input type="text" name="urun_adi" placeholder="<?php echo $satir['urun_adi']; ?>"
                                                class="form-control form-control-line">
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label class="col-md-12">Ürün Türü</label>
                                        <div class="col-md-12">
                                            <input type="text" name="category_id" placeholder="<?php echo $satir['category_id']; ?>"
                                                class="form-control form-control-line">
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label class="col-md-12">Ürün Fiyatı</label>
                                        <div class="col-md-12">
                                            <input type="text" name="urun_fiyat" placeholder="<?php echo $satir['urun_fiyat']; ?>"
                                                class="form-control form-control-line">
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label class="col-md-12">Ürün Açıklaması</label>
                                        <div class="col-md-12">
                                            <input type="text" name="urun_desc" placeholder="<?php echo $satir['urun_desc']; ?>"
                                                class="form-control form-control-line">
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label class="col-md-12">Ürün Fotoğrafı</label>
                                        <div class="col-md-12">
                                        <input type="file" name="urun_foto"  class="form-control form-control-line"/>
                                                
                                        </div>
                                    </div>

                                    <div class="form-group">
                                        <div class="col-sm-12">
                                        <input type="submit" name="kaydet"  value="Update" class="btn btn-success text-white">
                                        </div>
                                    </div>
                                </form>
                                <?php
                                
$host = "localhost";
$vt_adi = "saplament";
$kullanici_adi = "admin";
$sifre = "123456";
try {
    $con = new PDO("mysql:host={$host};dbname={$vt_adi}", $kullanici_adi, $sifre,
    array(PDO::MYSQL_ATTR_INIT_COMMAND => "SET NAMES utf8"));
    }
catch(PDOException $exception){
    echo "Bağlantı hatası: " . $exception->getMessage();
    }
                                
 if($_POST){

 try{
 $sorgu = "UPDATE product SET urun_adi=:urun_adi, urun_fiyat=:urun_fiyat,
category_id=:category_id,urun_desc=:urun_desc,urun_foto=:urun_foto  WHERE id = :id";
//$foto="SELECT urun_foto FROM product WHERE id=".$_GET['id'];

$stmt = $con->prepare($sorgu);
 $urunAdi=htmlspecialchars(strip_tags($_POST['urun_adi']));
 $urunFiyat=htmlspecialchars(strip_tags($_POST['urun_fiyat']));
 $urunTuru=htmlspecialchars(strip_tags($_POST['category_id']));
 $urunDesc=htmlspecialchars(strip_tags($_POST['urun_desc']));
 $urunFoto=htmlspecialchars(strip_tags('resim/'.$_POST['urun_foto']));

 $stmt->bindParam(':urun_adi', $urunAdi);
 $stmt->bindParam(':urun_fiyat', $urunFiyat);
 $stmt->bindParam(':category_id', $urunTuru);
 $stmt->bindParam(':urun_desc', $urunDesc);
 $stmt->bindParam(':urun_foto',$urunFoto);
 $stmt->bindParam(':id', $_GET['id']);

 if($stmt->execute()){
 echo "<div class='alert alert-success'>Kayıt güncellendi.</div>";
}else{
    echo "<div class='alert alert-danger'>Kayıt güncellenemedi.</div>";
    }
   
    }
    catch(PDOException $exception){
    die('HATA: ' . $exception->getMessage());
    }
    }
   ?>
    
                            </div>
                        </div>
                    </div>
                    <!-- Column -->
                </div>
                <!-- Row -->
                <!-- ============================================================== -->
                <!-- End PAge Content -->
                <!-- ============================================================== -->
                <!-- ============================================================== -->
                <!-- Right sidebar -->
                <!-- ============================================================== -->
                <!-- .right-sidebar -->
                <!-- ============================================================== -->
                <!-- End Right sidebar -->
                <!-- ============================================================== -->
            </div>
            <!-- ============================================================== -->
            <!-- End Container fluid  -->
            <!-- ============================================================== -->
            <!-- ============================================================== -->
            <!-- footer -->
            <!-- ============================================================== -->
            
            <!-- ============================================================== -->
            <!-- End footer -->
            <!-- ============================================================== -->
        </div>
        <!-- ============================================================== -->
        <!-- End Page wrapper  -->
        <!-- ============================================================== -->
    </div>
    <!-- ============================================================== -->
    <!-- End Wrapper -->
    <!-- ============================================================== -->
    <!-- ============================================================== -->
    <!-- All Jquery -->
    <!-- ============================================================== -->
    <script src="../../assets/libs/jquery/dist/jquery.min.js"></script>
    <!-- Bootstrap tether Core JavaScript -->
    <script src="../../assets/libs/bootstrap/dist/js/bootstrap.bundle.min.js"></script>
    <script src="../../dist/js/app-style-switcher.js"></script>
    <!--Wave Effects -->
    <script src="../../dist/js/waves.js"></script>
    <!--Menu sidebar -->
    <script src="../../dist/js/sidebarmenu.js"></script>
    <!--Custom JavaScript -->
    <script src="../../dist/js/custom.js"></script>
</body>

</html>
<?php } else{

echo "<script> window.location.href='../../admin/logout.php'</script>";
  }  ?>