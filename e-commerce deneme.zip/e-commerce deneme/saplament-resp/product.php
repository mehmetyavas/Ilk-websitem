<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="css/product-style.css">
    
  
</head>
<body>
    <?php
include("baglan.php");

if($_POST)
{
	
mysqli_set_charset($baglanti,"utf8");
$UrunAdi = $_POST["UrunAdi"];
$UrunFiyat = $_POST["UrunFiyat"];
$UrunType=$_POST["UrunType"];
$UrunDesc = $_POST["UrunDesc"];
$dizin='resim/';
$yuklenecekDosya=$dizin.basename($_FILES['urun_foto']['name']);
move_uploaded_file($_FILES['urun_foto']['tmp_name'],$yuklenecekDosya);
if($ekle = mysqli_query($baglanti,"INSERT INTO product(urun_adi,urun_fiyat,category_id
,urun_desc,urun_foto)
 VALUES('$UrunAdi','$UrunFiyat','$UrunType','$UrunDesc','$yuklenecekDosya')"));
 {
   echo "<script>alert(\"Veri basaşırı bir şekilde yazıldı.\");</script>";
 }
}
?>

<div class="container">
    <div class="content">
      <form action="product.php" method="post" enctype="multipart/form-data">
        <p >
            Ürün Adı=
            <input type="text" name="UrunAdi" id="UrunAdi"  class="urun-adi">
        </p>
        <p>
            Ürün Fiyatı=
            <input type="text" name="UrunFiyat" id="UrunFiyat"  class="urun-fiyat">
        </p>
        <p>
            Ürün Tipi=
            <input type="text" name="UrunType" id="UrunType"class="urun-type"  >
        </p>
        <p> Ürün Açıklaması=
            <input type="text" name="UrunDesc" id="UrunDesc" class="urun_desc">
        </p>
        <input type="file" name="urun_foto"/>
        <p class="submit">
            <input type="submit" name="kaydet" id="kaydet" value="kaydet" class="submit" />
        </p>
        </form>
    </div>
    <div class="table">  
<table border="1" >
<th> ID </th>
<th> Ürün Adı </th>
<th> Ürün Fiyatı </th>
<th> Ürün Tipi </th>
<th> Ürün Açıklaması </th>
<th> Fotoğraf </th>
<?php
 $baglanti= mysqli_connect('localhost','admin','123456','saplament');

/* if(!$baglanti){
	
echo "Bağlantı Hatası!".mysqli_connect_error();
}
else{
	
echo "Veritabanına Başarıyla Bağlandı";
} */ 

$sonuc = mysqli_query($baglanti," SELECT * FROM product");

while($satir= mysqli_fetch_array($sonuc)){
	
echo '<tr>';	
echo '<td>'.$satir['id'].'</td>'; 

echo '<td>'.$satir['urun_adi'].'</td>'; 	
echo '<td>'.$satir['urun_fiyat'].'₺</td>'; 
echo '<td>'.$satir['category_id'].'</td>'; 
echo '<td>'.$satir['urun_desc'].'</td>'; 
echo '<td> <img src="'.$satir['urun_foto'].'" width="100px" height="100px"></td>';
echo '</tr>';

}




?>
</table>

</div>
</div>
</body>
</html>
