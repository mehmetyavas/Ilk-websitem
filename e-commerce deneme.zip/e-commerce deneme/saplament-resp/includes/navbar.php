<?php 
include("baglan.php");
?>
<nav>
    <ul class="ul-topbar">
        <a href="index.php"> 
            <li class="li-topbar"><i class="fa-solid fa-house ikon"></i>Home</li>
        </a>
        <a href=""> <li class="li-topbar"> <i class="fa-solid fa-arrow-right-to-bracket ikon"></i>Giriş</li>
        </a>
        <a href="cart.php" >
        
        <li class="li-topbar"><span class="sayi">
            <?php
            $sql=mysqli_query($baglanti,"SELECT sum(urun_adet) as 'sayi'  from cart ");
            $satir=mysqli_fetch_array($sql);
            $urun_id=$satir['sayi'];
            echo $urun_id ;
            
            
            ?>
            
        </span>
        
        <!-- <span class="badge badge-light" id="urun-sayisi"> 
            
            <?php 
            $urun_sayisi=count($_SESSION['sepet']);
            echo $urun_sayisi; 
            ?>
            </span> -->
        
        <i class="fa-solid fa-basket-shopping ikon"></i>
        
        Sepet</li>
        </a>
    </ul>
</nav>