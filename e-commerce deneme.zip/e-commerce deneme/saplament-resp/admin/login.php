<?php

include("baglan.php");
ob_start();
session_start();
$K_Adi=$_POST['K_Adi'];
$Sifre=$_POST['Sifre'];
$getir=$baglanti->query("SELECT * FROM kullanici WHERE K_Adi='$K_Adi' and Sifre='$Sifre'");
if ($satir=mysqli_fetch_array($getir)) {
    $_SESSION["kullanici"]="true";
    $_SESSION["K_Adi"]=$K_Adi;
    $_SESSION["Sifre"]=$Sifre;
    header("location:../html/ltr/dashboard.php");
    exit();
}else {
        echo"Kullnıcı adı adı ya da şifre geçersiz";
       
        header("refresh:1; url=index.php");
}



?>