<?php
require 'db_conn.php';

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>PANEL</title>
    <link rel="stylesheet" href="../css/login.css">
    
</head>
<body>
<div class="center">
    <form action="login.php" method="post" autocomplete="off">
    <div class="txt_field">
        <input type="text" name="K_Adi"required>
        <label >Username</label><br>
    </div>
    <div class="txt_field">
        <input type="password" name="Sifre"required>
        <label >Password</label><br>
    </div>
    <input type="submit" value="Login">
</div>
    </form>
</div>
</body>
</html>