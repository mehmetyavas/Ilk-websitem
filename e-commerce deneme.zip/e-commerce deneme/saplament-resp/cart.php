<?php 
include("db_conn.php");

$stmt = $conn -> prepare('SELECT product.id, product.urun_adi ,product.urun_fiyat, product.urun_foto, product.category_id, cart.urun_adet FROM product INNER JOIN cart ON cart.urun_id = product.id');
$stmt -> execute();

$cart_items = $stmt -> fetchAll(PDO::FETCH_ASSOC);

?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Saplament | Anasayfa</title>
    
    <link rel="icon" type="image/png" sizes="16x16" href="assets/images/favicon.png">
    <!-- CSS only -->
    <link rel="stylesheet" href="css/cart.css">
    
    <link href="html/ltr/dist/css/style.min.css" rel="stylesheet">
    <link href="html/ltr/dist/css/style.css" rel="stylesheet">

<!-- font -->


    <script src="https://cdn.jsdelivr.net/npm/jquery@3.6.0/dist/jquery.slim.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/js/bootstrap.bundle.min.js"></script>
<script src="https://kit.fontawesome.com/996064a3d3.js" crossorigin="anonymous"></script>    
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0-beta1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-0evHe/X+R7YkIZDRvuzKMRqM+OrBnVFBL6DOitfPri4tjfHxaWutUpFmBp4vmVor" crossorigin="anonymous">

</head>
<body>
    <div class="banner"></div>
    <div class="wrapper-row1">
    <div class="container">
    
        <div id="topbar" class="clear-topbar">
            
        <?php include("includes/navbar.php"); ?>
        </div>
    </div>
    </div>
   
    <div class="wrapper-row2">
    <div class="container cont-row-2 " >
    <div id="hgroup order-1" >
                <h1 class="logo">
                    <a href="#">Saplament</a>
                </h1>
                <small>Protein, Yardımcılar, Vitaminler</small>
            </div>

            <div class="row">     
                    <header id="header">
            
            
        </header>
        </div>
        </div>
        </div>
    <div class="wrapper-row3">
        <div class="container">
            <!--index-urun.php START-->
            <div class="row">
            <div class="content">
            <div class="table-responsive">
                                <table class="table table-bordered">
                                    <thead>
                                        <tr>
                                            <th scope="col">#</th>
                                            <th scope="col">Fotoğraf</th>
                                            <th scope="col">Ürün adı</th>
                                            <th scope="col"> Fiyat</th>
                                            <th scope="col">Adet</th>
                                            <th scope="col">Toplam Fiyat</th>
                                            <th scope="col">Sil</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                    
                                    <?php foreach ($cart_items as $item) : ?>
                                    <tr>
                                        <th scope="row"><?php echo $item['id']; ?></th>
                                        <td style="display:flex;justify-content:center;align-items:center">
                                           <a href="urun.php?id=<?=$item['id'];?>"><img src="<?php echo $item['urun_foto']; ?>"
                                                class="figure-size" style="height:85px;width:85px"  ></a> 
                                    </td>
                                        <td style="text-align:center; padding-top: 35px;" >
                                        <?= $item['urun_adi']; ?>
                                    </td>
                                        <td style="text-align:center; padding-top: 35px;">
                                        <?= $item['urun_fiyat']; ?>₺
                                    </td>

                                        <td style="text-align:center; padding-top: 35px;">
                                        <?= $item['urun_adet']; ?>
                                    </td>
                                        <td style="text-align:center; padding-top: 35px;">
                                        <?= number_format($item['urun_fiyat']*$item['urun_adet'], 2); ?>₺</td>
                                        <td style="text-align:center; padding-top: 35px;">
                                        <a href="cart-vt.php?id=<?=$item['id']?>&islem=sil">
                                        <i class="fa-solid fa-trash-can"></i></a></td>
                                        
                                        </a> </td>
                                    </tr>
                                    <?php endforeach; ?>

                                    </tbody>
                                </table>
                                
                            </div>

                            <div class="satin-al">
                           <a class="btn-a" href="cart.php"> <div class="satin-al-btn"> Sayfayı Güncelle</div></a>
                           <a class="btn-a" href="#"> <div class="satin-al-btn"> Satın AL</div></a>
                                 </div>





            </div>
            </div>
<!--index-urun.php  END-->
        </div>
    </div>

    <footer>
        <div class="footer">
            <div class="footer-container">
                <div class="footer-row">
                    <div class="footer-row1">
                      <h1 class="footer-h1">İletişim</h1>
                    <ul class="footer-ul">
                            <li><i class="fa-solid fa-location-pin ikon-footer"></i>
                        İzmir/Torbalı Cumhuriyet mah.no19</li>
                            <hr style="margin-bottom: 0px;margin-top: 0px;">
                            <li><i class="fa-solid fa-envelope ikon-footer"></i>
                            mehmett_234@outlook.com</li>
                            <hr style="margin-bottom: 0px;margin-top: 0px;">
                            <li> <i class="fa-solid fa-phone ikon-footer "></i>
                        0555 555 55 55</li>
                            <hr style="margin-bottom: 0px;margin-top: 0px;">
                            <li class="footer-aboutUs"><i class="fa-solid fa-envelope ikon-footer"></i>
                            <a href="iletisim.php" > Bize Ulaşın</a></li>
                            <hr style="margin-bottom: 0px;margin-top: 0px;">
                        </ul>
                    </div>
                    <div class="footer-row2">
                        <h1 class="footer-h1">
                            Bizi Takip Et
                        </h1>
                    <ul class="footer-ul-follow">
                            <li><a href=""><i class="fa-brands fa-instagram footer-ikon"></i></a></li>
                            <li><a href=""><i class="fa-brands fa-facebook footer-ikon"></i></a></li>
                            <li><a href=""><i class="fa-brands fa-twitter footer-ikon"></i></a></li>
                            <li><a href="https://www.youtube.com/watch?v=FJRMldSmy-M"><i class="fa-brands fa-youtube footer-ikon"></i></a></li>
                        </ul>
                    </div>
                    <div class="footer-row3">
                        <h1 class="footer-h1">Hakkımızda</h1>
                    <ul class="footer-ul footer-aboutUs">
                            <li><a href=""> Hakkımızda</a></li>
                            <hr style="margin-bottom: 0px;margin-top: 0px;">
                            <li><a href=""> Gizlilik Politikası</a></li>
                            <hr style="margin-bottom: 0px;margin-top: 0px;">
                            <li><a href="">Şartlar ve koşullar</a> </li>
                            <hr style="margin-bottom: 0px;margin-top: 0px;">
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </footer>
    
</body>
</html>