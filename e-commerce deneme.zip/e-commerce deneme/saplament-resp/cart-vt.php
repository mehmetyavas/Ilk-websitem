<?php

    include("db_conn.php");

    
    $urun_id = $_GET['id'];
    $adet = $_GET['urun_adet'] ?? 1;

    $cart = $conn -> prepare('SELECT * FROM cart WHERE urun_id =:id');
    $cart -> execute(array('id' => $urun_id));

    if (isset($_GET['islem']) && $_GET['islem'] === 'sil') {
        $delete = $conn -> prepare('DELETE FROM cart WHERE urun_id=:id');
        $delete -> execute(array('id' => $urun_id));

        header('Location: cart.php');
    } else {
        if ($cart -> rowCount() > 0) {
            echo $adet;
    
            $update = $conn -> prepare('UPDATE cart SET urun_adet = urun_adet + ' . $adet . ' WHERE urun_id =:id');
            $update -> execute(array(
                'id' => $urun_id
            ));
    
            if ($update -> rowCount() > 0) {
                header('Location:'.$_SERVER['HTTP_REFERER']);
            }
        } else {
            $insert = $conn -> prepare('INSERT INTO cart SET urun_id =:id, urun_adet =:adet');
            $insert -> execute(array('id' => $urun_id, 'adet' => $adet));
    
            if ($insert -> rowCount() > 0) {
                header('Location:'.$_SERVER['HTTP_REFERER']);
            }
        }
    
    }







        
?>