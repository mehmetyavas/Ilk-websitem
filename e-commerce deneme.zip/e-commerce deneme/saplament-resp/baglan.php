<?php

$baglanti=mysqli_connect('localhost','admin','123456','saplament');
mysqli_set_charset($baglanti,"UTF8");
if(!$baglanti){
    echo "cart curt".mysqli_connect_error();

}


/* uwhxlvlw_
'a4C%bBL4NrW~'*/
?>

