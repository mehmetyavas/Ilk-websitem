<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    
  
</head>
<body>
    <?php
include("baglan.php");

if($_POST)
{
	
mysqli_set_charset($baglanti,"utf8");
$ad = $_POST["ad"];
$soyad = $_POST["soyad"];
$tc = $_POST["tc"];
$bolum=$_POST["bolum"];
$cinsiyet = $_POST["cinsiyet"];
$dizin='../foto/';
$yuklenecekDosya=$dizin.basename($_FILES['foto']['name']);
move_uploaded_file($_FILES['foto']['tmp_name'],$yuklenecekDosya);
if($ekle = mysqli_query($baglanti,"INSERT INTO musteri(ad,soyad,tc,bolum,cinsiyet,foto) VALUES('$ad','$soyad','$tc','$bolum','$cinsiyet','$yuklenecekDosya')"));
 {
   echo "Veri başarılı bir şekilde ekrana yazıldı";
 }
}
?>
    <div class="container">
    <form action="" method="post" enctype="multipart/form-data">
        <p >
            Ad=
            <input type="text" name="ad" id="ad" value="ad" class="ad">
        </p>
        <p>
            Soyad=
            <input type="text" name="soyad" id="soyad" value="soyad" class="soyad">
        </p>
        <p>
            TC Kimlik=
            <input type="text" name="tc" id="tc" value="tc" >
        </p>
        <p>
            Bölüm=
            <input type="text" name="bolum" id="bolum" value="bolum" class="bolum">
        </p><div class="radio">  
        <p class="radioErkek">
           Erkek= <input type="radio" name="cinsiyet" id="cinsiyet" value="erkek" />
        </p>
        <p class="radioKadin">
           Kadın= <input type="radio" name="cinsiyet" id="cinsiyet" value="kadın" />
        </p> 
        <p>&nbps</p>
        <input type="file" name="foto"/>
    </div>
    <p class="submit">
        <input type="submit" name="kaydet" id="kaydet" value="Submit" />
    </p>
    </form>
    
</div>
<div class="table">  
<table border="1" >
<th> ID </th>
<th> AD </th>
<th> SOYAD </th>
<th> TC </th>
<th> BÖLÜM </th>
<th> CİNSİYET </th>
<th> Fotoğraf </th>
<th> Güncelle </th>
<th> SİL </th>
<?php

 $baglanti= mysqli_connect('localhost','admin','123456','admin');

/* if(!$baglanti){
	
echo "Bağlantı Hatası!".mysqli_connect_error();
}
else{
	
echo "Veritabanına Başarıyla Bağlandı";
} */ 

$sonuc = mysqli_query($baglanti,"SELECT *FROM musteri");

while($satir= mysqli_fetch_array($sonuc)){
	
echo '<tr>';	
echo '<td>'.$satir['id'].'</td>'; 
echo '<td> <img src="'.$satir['foto'].'" alt="foto" width="100px"
 height="100px"></a></td>';
echo '<td>'.$satir['ad'].'</td>'; 	
echo '<td>'.$satir['soyad'].'</td>'; 
echo '<td>'.$satir['tc'].'</td>'; 
echo '<td>'.$satir['Bolum'].'</td>'; 
echo '<td>'.$satir['cinsiyet'].'</td>'; 
echo '<td> <a href ="Guncelle.php?id='.$satir['id'].'">Güncelle</a></td>';
echo '<td> <a href ="sil.php?id='.$satir['id'].'">Sil</a></td>';
echo '</tr>';

}




?>
</table>
</div>
</body>
</html>



<?php $sonuc = mysqli_query($baglanti," SELECT * FROM product  WHERE category_id=" .$category_id." ORDER BY id DESC");?>
