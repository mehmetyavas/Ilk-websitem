-- phpMyAdmin SQL Dump
-- version 4.9.7
-- https://www.phpmyadmin.net/
--
-- Anamakine: localhost:3306
-- Üretim Zamanı: 25 May 2022, 02:37:51
-- Sunucu sürümü: 10.3.34-MariaDB-cll-lve
-- PHP Sürümü: 7.4.29

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Veritabanı: `uwhxlvlw_saplament`
--

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `admins`
--

CREATE TABLE `admins` (
  `admin_id` int(11) NOT NULL,
  `admin_email` varchar(55) NOT NULL,
  `admin_pass` varchar(55) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Tablo döküm verisi `admins`
--

INSERT INTO `admins` (`admin_id`, `admin_email`, `admin_pass`) VALUES
(1, 'admin', '123456');

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `cart`
--

CREATE TABLE `cart` (
  `cart_id` int(11) NOT NULL,
  `urun_id` int(11) NOT NULL,
  `urun_adet` int(11) NOT NULL DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Tablo döküm verisi `cart`
--

INSERT INTO `cart` (`cart_id`, `urun_id`, `urun_adet`) VALUES
(58, 139, 1);

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `category`
--

CREATE TABLE `category` (
  `id` int(11) NOT NULL,
  `category_name` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Tablo döküm verisi `category`
--

INSERT INTO `category` (`id`, `category_name`) VALUES
(1, 'Protein'),
(2, 'Mass Gaining'),
(3, 'Performans ve Güç'),
(4, 'Vitaminler'),
(5, 'Sağlıklı Atıştırmalık');

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `iletisim`
--

CREATE TABLE `iletisim` (
  `id` int(11) NOT NULL,
  `adsoyad` varchar(50) NOT NULL,
  `telefon` int(12) NOT NULL,
  `email` varchar(32) NOT NULL,
  `konu` varchar(75) NOT NULL,
  `mesaj` varchar(300) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Tablo döküm verisi `iletisim`
--

INSERT INTO `iletisim` (`id`, `adsoyad`, `telefon`, `email`, `konu`, `mesaj`) VALUES
(3, 'mehmet', 55555555, 'mehmet.yvs347@gmail.com', 'Bütünleme sınavlarının online olması', ' dawdawdawdaw'),
(4, 'mehmet', 55555555, 'mehmet.yvs347@gmail.com', 'Bütünleme sınavlarının online olması', ' sda');

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `kullanici`
--

CREATE TABLE `kullanici` (
  `id` int(11) NOT NULL,
  `K_Adi` varchar(33) NOT NULL,
  `Sifre` int(33) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Tablo döküm verisi `kullanici`
--

INSERT INTO `kullanici` (`id`, `K_Adi`, `Sifre`) VALUES
(1, 'admin', 123456);

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `product`
--

CREATE TABLE `product` (
  `id` int(11) NOT NULL,
  `urun_adi` varchar(100) DEFAULT NULL,
  `urun_fiyat` decimal(10,2) DEFAULT NULL,
  `category_id` int(11) DEFAULT NULL,
  `urun_desc` varchar(150) DEFAULT NULL,
  `urun_foto` varchar(200) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Tablo döküm verisi `product`
--

INSERT INTO `product` (`id`, `urun_adi`, `urun_fiyat`, `category_id`, `urun_desc`, `urun_foto`) VALUES
(136, 'curt', '89.00', 1, 'lorem ipsum dolor sit amet', 'resim/scitec-WHEY.jpeg'),
(138, 'ewaewa', '231.00', 2, 'ıkky', 'resim/bellanut-fistikEzmesi.jpeg'),
(139, 'ewaewa', '231.00', 2, 'ıkky', 'resim/bellanut-fistikEzmesi.jpeg'),
(140, 'ewaewa', '231.00', 2, 'ıkky', 'resim/bellanut-fistikEzmesi.jpeg'),
(141, 'ewaewa', '231.00', 2, 'ıkky', 'resim/bellanut-fistikEzmesi.jpeg'),
(142, 'ewaewa', '231.00', 2, 'ıkky', 'resim/bellanut-fistikEzmesi.jpeg'),
(143, 'ewaewa', '231.00', 2, 'ıkky', 'resim/bellanut-fistikEzmesi.jpeg'),
(158, 'cart', '23.00', 0, 'akwoawkroaw', 'resim/supplementlercom_whey_protein_2000_gr_17228.jpeg'),
(159, 'emir', '3155.00', 5, 'emir guner', 'resim/supplementlercom_whey_protein_2000_gr_17228.jpeg'),
(160, 'Husoo', '58269.00', 3, 'ALperenİsmail', 'resim/supplementlercom_whey_protein_2000_gr_17228.jpeg'),
(161, 'mrotein', '532.00', 3, 'Extra mega ultra protein yanında cart curt', 'resim/indir.jpg'),
(162, 'otocomplete', '222.00', 4, 'mehmet mehmet mehmet mehmet mehmet mehmet mehmet mehmet mehmet mehemt mehme tm mehmet mehmet mehmet mehemt mehmetmehemt', 'resim/predator.jpeg'),
(167, 'emre', '313.00', 1, 'lesgo', 'resim/Mass-ProGainer.jpeg'),
(168, 'otoket', '89.00', 1, 'lorem ipsum dolor sit amet', 'resim/Supplementler-WHEY.jpeg'),
(169, 'sodık', '881.00', 1, 'lorem ipsum dolor sit amet consectetur ', 'resim/Mass-ProGainer.jpeg'),
(170, 'wheYYYY', '199.00', 1, 'whey protein en kaliteli protein whey iyidir', 'resim/supplementlercom_whey_protein_2000_gr_17228.jpeg'),
(171, 'scitec protein', '299.00', 1, 'scitec protein whey protein lesgoo', 'resim/scitec-WHEY.jpeg'),
(172, 'RSSI30MT protein', '449.00', 1, 'rssi protein sinyal ölçen protein güzel ölçer', 'resim/rssi30mt.png'),
(173, 'hardline vitamin', '199.00', 4, 'binAbbas', 'resim/hardline-vitamin.jpeg'),
(174, 'tufan kreatin', '99.00', 3, 'kreatin iyidir', 'resim/bellanut-fistikEzmesi.jpeg'),
(175, 'otoket', '3333.00', 2, 'mehmet21', 'resim/predator.jpeg');

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `tbladmin`
--

CREATE TABLE `tbladmin` (
  `ID` int(11) NOT NULL,
  `UserName` varchar(50) DEFAULT NULL,
  `Password` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Tablo döküm verisi `tbladmin`
--

INSERT INTO `tbladmin` (`ID`, `UserName`, `Password`) VALUES
(1, 'admin', '123456');

--
-- Dökümü yapılmış tablolar için indeksler
--

--
-- Tablo için indeksler `admins`
--
ALTER TABLE `admins`
  ADD PRIMARY KEY (`admin_id`);

--
-- Tablo için indeksler `cart`
--
ALTER TABLE `cart`
  ADD PRIMARY KEY (`cart_id`);

--
-- Tablo için indeksler `category`
--
ALTER TABLE `category`
  ADD PRIMARY KEY (`id`);

--
-- Tablo için indeksler `iletisim`
--
ALTER TABLE `iletisim`
  ADD PRIMARY KEY (`id`);

--
-- Tablo için indeksler `kullanici`
--
ALTER TABLE `kullanici`
  ADD PRIMARY KEY (`id`);

--
-- Tablo için indeksler `product`
--
ALTER TABLE `product`
  ADD PRIMARY KEY (`id`);

--
-- Tablo için indeksler `tbladmin`
--
ALTER TABLE `tbladmin`
  ADD PRIMARY KEY (`ID`);

--
-- Dökümü yapılmış tablolar için AUTO_INCREMENT değeri
--

--
-- Tablo için AUTO_INCREMENT değeri `admins`
--
ALTER TABLE `admins`
  MODIFY `admin_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- Tablo için AUTO_INCREMENT değeri `cart`
--
ALTER TABLE `cart`
  MODIFY `cart_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=59;

--
-- Tablo için AUTO_INCREMENT değeri `category`
--
ALTER TABLE `category`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- Tablo için AUTO_INCREMENT değeri `iletisim`
--
ALTER TABLE `iletisim`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- Tablo için AUTO_INCREMENT değeri `kullanici`
--
ALTER TABLE `kullanici`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- Tablo için AUTO_INCREMENT değeri `product`
--
ALTER TABLE `product`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=176;

--
-- Tablo için AUTO_INCREMENT değeri `tbladmin`
--
ALTER TABLE `tbladmin`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
